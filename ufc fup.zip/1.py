v=float(input())
s=v*5.27
print(f'{s:.2f}')