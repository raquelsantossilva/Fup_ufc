n1 = float(input())
n2 = float(input())
n3 = float(input())
s = (n1**2)+(n2**2)+(n3**2)
print(f'{s:.2f}')
qs = n1+n2+n3
q = qs*2
print(f'{q:.2f}')