sv=float(input())
a=sv*0.2137
ns=sv+a
print(f"{ns:.2f}")