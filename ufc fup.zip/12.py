total=float(input())
v1=(total*46)/100
print(f'{v1:.2f}')
v2=(total*32)/100
print(f'{v2:.2f}')
v3=(total*22)/100
print(f'{v3:.2f}')