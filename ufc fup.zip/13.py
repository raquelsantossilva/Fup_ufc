num=(input())
ni=int(num[::-1])
print(f'{ni:.2f}')