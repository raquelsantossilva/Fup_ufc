import math
x=float(input())
y=float(input())
hipotenusa=math.sqrt(x**2+y**2)
print(f'{hipotenusa:.2f}')