nome=(input())
print(nome)