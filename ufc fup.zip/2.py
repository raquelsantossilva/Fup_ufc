l1=float(input())
l2=float(input())
p=(2*l1)+(2*l2)
a=l1*l2
print(f'{a:.2f}')
print(f'{p:.2f}')