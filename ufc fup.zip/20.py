nome=(input())
print(len(nome))