nome=(input())
n1=nome[0]
n2=nome[1]
n3=nome[2]
n4=nome[3]
print(n1+n2+n3+n4)