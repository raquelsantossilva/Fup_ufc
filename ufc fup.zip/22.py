S=input()
i=int(input())
j=int(input())
s1=S[i-1:j]
print(s1)