carac=(input()).upper()
print(carac)