m=(input()).lower()
print(m)