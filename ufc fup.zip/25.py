e=(input()).replace(' ','')
print(e)