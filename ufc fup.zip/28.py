s1=(input())
s2=(input())
comp=len(s2)
r=s1[-comp:]==s2
print(r)