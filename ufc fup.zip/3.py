n=int(input())
a=n-1
s=n+1
print(a)
print(s)