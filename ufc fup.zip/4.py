l=float(input())
a=l*l
print(f'{a:.2f}')