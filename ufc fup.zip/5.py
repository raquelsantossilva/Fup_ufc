import math
r = float(input())
v = (4 / 3) *math.pi * (r ** 3)
a = (4 * math.pi) * (r ** 2)
print(f"{v:.2f}")
print(f'{a:.2f}')