r=float(input())
q=r**2
print(f'{q:.2f}')