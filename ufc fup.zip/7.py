C=float(input())
F = C * (9.0/5.0) + 32
print(f'{F:.2f}')