km=float(input())
m=km/3.6
print(f'{m:.2f}')