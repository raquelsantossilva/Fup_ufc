g=float(input())
rad=(g*3.14)/180
print(f' {rad:.2f}')